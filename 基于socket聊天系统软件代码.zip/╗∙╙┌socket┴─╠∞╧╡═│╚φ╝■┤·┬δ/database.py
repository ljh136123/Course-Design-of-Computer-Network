import pymysql
import pymssql
class DB(object):
    #
    def __init__(self):
        #连接到数据库
        self.connect=pymssql.connect('LAPTOP-TB9KOSKI','sa','123456','chat_room')
        #获取游标
        self.cursor=self.connect.cursor();

    def getone(self,sql):
        #执行sql语句
        self.cursor.execute(sql)
        #获取查询结果
        query_result=self.cursor.fetchone()

        #判断是否有结果
        if not query_result:
            return None
        #获取字段名称列表
        fileds=[filed[0] for filed in self.cursor.description ]
        #讲字段和结果组合在一起
        return_data={}
        for filed,value in zip(fileds,query_result):
            return_data[filed]=value

        return return_data

    def insert(self,sql):
        self.cursor.execute(sql)
        self.connect.commit()
    def close(self):
        self.cursor.close()
        self.connect.close()


# if __name__=='__main__':
#     db=DB()
#     data=db.getone("select * from users where user_name='user2'")
#     print(data)
#     db.close()