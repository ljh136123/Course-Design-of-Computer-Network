from server.server import *
class RequestProtocol(object):
    @staticmethod
    def request_login_result(username,password):

        return DELIMITER.join([REQUEST_LOGIN,username,password])

    @staticmethod
    def request_chat(nickname, messages):
        return DELIMITER.join([REQUEST_CHAT,  nickname,messages])

    @staticmethod
    def request_sendfile(messages,filename,size):
        return DELIMITER.join(['0003',filename,messages,str(size)])