from window import login_window
from request_protocol import RequestProtocol
from clinet_socket import ClientSocket
from server.server import *
from tkinter.messagebox import showinfo
from window_chat import windowchat
from window_register import registerwindow
from database import DB
from send_file import sendFilewindow
import os
import socket
import sys
import struct
class Client(object):
    #核心类
    def __init__(self):
        self.windows=login_window()
        self.windows.login_button_click(self.send_login)
        self.windows.regist_button_click(self.registering)

        self.conn=ClientSocket()
        #self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        self.db=DB()

        self.SendFile=sendFilewindow()
        self.chatWindow=windowchat()
        self.registerwindow=registerwindow()
        self.chatWindow.withdraw()#隐藏
        self.SendFile.withdraw()
        self.registerwindow.withdraw()
        self.chatWindow.button_click(self.send_chat_data)
        self.chatWindow.sendfile_button_click(self.open_send_file)
        self.SendFile.send_file_button(self.send_file)
        self.registerwindow.click_regist_button(self.register)

        self.response_handle_function = {}
        self.response_handle_function[RESPONSE_LOGN_RESULT] = self.response_login_handle
        self.response_handle_function[RESPONSE_CHAT] = self.respnse_chat_handle

        self.username=None
    def startup(self):
        self.conn.connect()
        #self.s.connect(('127.0.0.2', 6666))
        Thread(target=self.response_handle).start()
        self.windows.mainloop()

    def send_login(self):
        username=self.windows.get_username()
        password=self.windows.get_password()
        request=RequestProtocol.request_login_result(username,password)
        print("登录账号密码："+request)
        self.conn.send_data(request)

    def send_file(self):

        filepath = self.SendFile.get_fielname() # 输入当前目录下的图片名 xxx.jpg
        size=os.path.getsize(filepath)
        #self.conn.send_data(str(size))
        fp = open(filepath, 'rb')  # 打开要传输的图片
        data = fp.read(1024)  # 读入图片数据
        if not data:
            print('{0} send over...'.format(filepath))
        self.conn.send(data)  # 以二进制格式发送图片数
        print('okk')
        showinfo('提示', '发送成功')
              # 以二进制格式发送图片数据
        #self.chatWindow.update()  # 刷新窗口
        self.chatWindow.deiconify()
        # 隐藏登录窗口
        self.SendFile.withdraw()
    def open_send_file(self):
        self.SendFile.update()  # 刷新窗口
        self.SendFile.deiconify()
        # 隐藏登录窗口
        self.chatWindow.withdraw()

    def response_handle(self):
        while True:
            recvdata=self.conn.recv_data()
            print("收到消息为" + recvdata)
            response_data=self.parse_response_text(recvdata)
            handle_function = self.response_handle_function[response_data["response_id"]]
            if handle_function:
                handle_function(response_data)

    def parse_response_text(self, recv_data):
        # 解析客户端数据
        # 登录信息格式 0001|username|password
        # 聊天信息格式 0002|username|msg

        data_list = recv_data.split("|")
        response_data = {}
        response_data["response_id"] = data_list[0]
        if response_data["response_id"] == RESPONSE_LOGN_RESULT:
            response_data["result"] = data_list[1]
            response_data["nickname"] = data_list[2]
            response_data['username']=data_list[3]
        elif response_data["response_id"] == RESPONSE_CHAT:
            response_data["nickname"] = data_list[1]
            response_data["message"] = data_list[2]
        return response_data

    def response_login_handle(self,response_data):
        result=response_data['result']
        if result=='0':
            showinfo('提示','登录失败')
            print('登录失败')
            return

        showinfo('提示','登录成功')
        nickname=response_data['nickname']
        self.username=response_data['username']

        #显 示聊天窗口
        self.chatWindow.set_title(nickname)
        self.chatWindow.update()#刷新窗口
        self.chatWindow.deiconify()
        #隐藏登录窗口
        self.windows.withdraw()

    def send_chat_data(self):
        message=self.chatWindow.get_input()
        self.chatWindow.clear_input()

        request=RequestProtocol.request_chat(self.username,message)

        #发送消息
        self.conn.send_data(request)

        self.chatWindow.append_message("我",message)
    def respnse_chat_handle(self,response_data):
        print("接受到聊天消息：",response_data)
        sender=response_data["nickname"]
        message=response_data["message"]
        self.chatWindow.append_message(sender,message)

    def register(self):
        username1=self.registerwindow.get_username()
        password=self.registerwindow.get_password()
        passwordnew=self.registerwindow.get_passwordnew()
        nickname1=self.registerwindow.get_nickname()
        if password!=passwordnew:
            showinfo('提示', '两次输入密码不正确，注册失败')
            print('注册失败')
            return
        sql = "select * from users1 where user_name='" + username1 + "'"
        result = self.db.getone(sql)

        # 没有结果说明用户不存在
        if result:
            showinfo('提示', '已经注册')
            print('注册失败')
            return

        sql1="INSERT INTO users1 values('"+username1+"','"+password+"','"+nickname1+"')"
        self.db.insert(sql1)
        showinfo('提示', '注册成功')
        self.windows.update()#刷新窗口
        self.windows.deiconify()
        #隐藏登录窗口
        self.registerwindow.withdraw()
    def registering(self):
        self.registerwindow.update()  # 刷新窗口
        self.registerwindow.deiconify()
        # 隐藏登录窗口
        self.windows.withdraw()

if __name__ == '__main__':
    clients=Client()
    clients.startup()

