from tkinter import Tk
from tkinter import Label
from tkinter import Entry
from tkinter import Frame
from tkinter import Button
from tkinter import LEFT
class login_window(Tk):
    #登录窗口
    def __init__(self):
        #初始化窗口
        super(login_window, self).__init__()
        #设置窗口属性
        self.window_init()

        #填充控件
        self.add_widgets()

        #self.login_button_click(lambda :print(self.get_username()))
    def window_init(self):
        self.title("登录")
        #self.resizable(False)
        self.geometry('300x150+%d+%d'% (600,300))

    def add_widgets(self):
       #用户名
        username_lable=Label(self)
        username_lable['text']='用户名:'
        username_lable.grid(row=0,column=0,padx=10,pady=5)

        username_entry=Entry(self,name='username_entry')
        username_entry['width']=30
        username_entry.grid(row=0,column=1,pady=15)

        #密码

        password_lable = Label(self)
        password_lable['text'] = '密 码:'
        password_lable.grid(row=1, column=0, padx=10, pady=5)

        password_entry = Entry(self, name='password_entry')
        password_entry['width'] = 30
        password_entry['show'] = '*'
        password_entry.grid(row=1, column=1,pady=10)


        #按钮区
        button_frame=Frame(self,name='button_frame')

        login_button=Button(button_frame,name='login_button')
        login_button['text']=' 登录 '
        login_button.pack(side=LEFT,padx=20)

        regist_button = Button(button_frame, name='regist_button')
        regist_button['text'] = ' 注册 '
        regist_button.pack(side=LEFT, padx=20)
        button_frame.grid(row=2,columnspan=2,pady=10)

    def get_username(self):
        return self.children['username_entry'].get()
    def get_password(self):
        return self.children['password_entry'].get()

    def login_button_click(self,command):
        login_button=self.children['button_frame'].children['login_button']
        login_button["command"]=command

    def regist_button_click(self,command):
        regist_button=self.children['button_frame'].children['regist_button']
        regist_button['command']=command

# if __name__ == '__main__':
#     windows = login_window()
#     windows.mainloop()
