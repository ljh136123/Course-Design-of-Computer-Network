from tkinter import Toplevel
from tkinter.scrolledtext import ScrolledText
from tkinter import Text
from tkinter import Button
from tkinter import END
from time import *
from tkinter import UNITS
from tkinter import Frame
from tkinter import TOP
class windowchat(Toplevel):

    def __init__(self):
        super(windowchat, self).__init__()
        self.geometry("800x500")

        self.resizable(False,False)

        chat_text_area =ScrolledText(self)
        chat_text_area['width']=110
        chat_text_area['height']=30
        chat_text_area.grid(row=0,column=0,columnspan=2)

        chat_text_area.tag_config('green',foreground="#008B00")

        self.children['chat_text_area']=chat_text_area
        chat_input_area=Text(self,name='chat_input_area')
        chat_input_area['width'] = 100
        chat_input_area['height'] = 7
        chat_input_area.grid(row=1, column=0)


        button_frame=Frame(self,name='button_frame')

        send_button = Button(button_frame, name='send_button')
        send_button['text'] = '发送'
        send_button.pack(side=TOP,pady=5)

        sendfile_button = Button(button_frame, name='sendfile_button')
        sendfile_button['text'] = ' 发送文件 '
        sendfile_button.pack(side=TOP, pady=5)
        button_frame.grid(row=1,column=1,pady=10)

        # send_button = Button(self, name='send_button')
        # send_button['text'] = '发送'
        # send_button['width']=5
        # send_button['height']=2
        # send_button.grid(row=1,column=1,pady=10)

        #self.button_click(lambda:self.append_message('ljh真帅',' 你好鸭'))
    def set_title(self,title):
        self.title('欢迎'+title+'进入聊天室! ')

    def sendfile_button_click(self,command):
        self.children["button_frame"].children['sendfile_button']['command']=command

    def  button_click(self,command):
        self.children["button_frame"].children["send_button"]['command']=command

    def get_input(self):
        return self.children['chat_input_area'].get(0.0,END)

    def clear_input(self):
        self.children['chat_input_area'].delete(0.0,END)

    def append_message(self,sender,message):
        send_time=strftime("%Y-%m-%d %H:%M:%S",localtime(time()))
        send_info ='%s:%s\n'%(sender,send_time)
        self.children['chat_text_area'].insert(END,send_info,'green')
        self.children['chat_text_area'].insert(END, message+'\n')

        #向下滚动
        self.children['chat_text_area'].yview_scroll(3,UNITS)

    def window_closed(self,command):
        self.protocol('WM_DELETE_WINDOW',command)
