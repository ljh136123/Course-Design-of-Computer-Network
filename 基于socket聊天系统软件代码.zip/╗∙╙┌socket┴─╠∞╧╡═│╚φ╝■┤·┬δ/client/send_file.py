from tkinter import Tk
from tkinter import Label
from tkinter import Entry
from tkinter import Frame
from tkinter import Button
from tkinter import LEFT

class sendFilewindow(Tk):
    #登录窗口
    def __init__(self):
        #初始化窗口
        super(sendFilewindow, self).__init__()
        self.geometry('300x150+%d+%d' % (600, 300))
        self.title("发送文件")
        filename_lable = Label(self)
        filename_lable['text'] = '文件名地址:'
        filename_lable.grid(row=0, column=0, padx=10, pady=5)

        filename_entry = Entry(self, name='filename_entry')
        filename_entry['width'] = 25
        filename_entry.grid(row=0, column=1, pady=15)

        register_button = Button(self, name='sendfile_button')
        register_button['text'] = '发送文件'
        register_button['width'] = 10
        register_button['height'] = 2
        register_button.grid(row=1, columnspan=2, pady=10, padx=30)

    def get_fielname(self):
        return  self.children['filename_entry'].get()
    def send_file_button(self,command):
        self.children['sendfile_button']['command'] = command

if __name__ == '__main__':
    windows = sendFilewindow()
    windows.mainloop()