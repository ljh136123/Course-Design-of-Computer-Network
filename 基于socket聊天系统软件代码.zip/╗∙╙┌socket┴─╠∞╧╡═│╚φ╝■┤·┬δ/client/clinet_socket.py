import socket
from server.server import *
class ClientSocket(socket.socket):
    #客户端套接字
    def __init__(self):
        super(ClientSocket, self).__init__(socket.AF_INET,socket.SOCK_STREAM)#设置ipv4地址，tcp协议

    def connect(self):
        super(ClientSocket, self).connect((SERVER_IP,SERVER_PORT))#设置连接到服务器的ip和地址

    def recv_data(self):
        #接受数据
        return self.recv(1024).decode('utf-8')

    def send_data(self,message):
        return self.send(message.encode('utf-8'))