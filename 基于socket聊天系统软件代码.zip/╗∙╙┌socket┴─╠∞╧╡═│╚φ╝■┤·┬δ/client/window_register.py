from tkinter import Toplevel
from tkinter import Text
from tkinter import Button
from tkinter import END
from tkinter import Label
from tkinter import Entry
from tkinter import Frame
from tkinter import LEFT
from tkinter import CENTER
class registerwindow(Toplevel):
    def __init__(self):
        super(registerwindow, self).__init__()
        self.geometry('325x250+%d+%d' % (600, 300))
        self.resizable(False, False)

        self.title("注册")
        # self.resizable(False)

        username_lable = Label(self)
        username_lable['text'] = '用户名:'
        username_lable.grid(row=0, column=0, padx=10, pady=5)

        username_entry = Entry(self, name='username_entry')
        username_entry['width'] = 25
        username_entry.grid(row=0, column=1, pady=15)

        nick_lable = Label(self)
        nick_lable['text'] = '昵称:'
        nick_lable.grid(row=1, column=0, padx=10, pady=5)

        nick_entry = Entry(self, name='nick_entry')
        nick_entry['width'] = 25
        nick_entry.grid(row=1, column=1, pady=15)

        # 密码

        password_lable = Label(self)
        password_lable['text'] = '密 码:'
        password_lable.grid(row=2, column=0, padx=10, pady=5)

        password_entry = Entry(self, name='password_entry')
        password_entry['width'] = 25
        password_entry['show'] = '*'
        password_entry.grid(row=2, column=1, pady=10)

        password_lablenew = Label(self)
        password_lablenew['text'] = '再次确认密码:'
        password_lablenew.grid(row=3, column=0, padx=10, pady=5)

        password_entrynew = Entry(self, name='password_entrynew')
        password_entrynew['width'] = 25
        password_entrynew['show'] = '*'
        password_entrynew.grid(row=3, column=1, pady=10)

        register_button = Button(self, name='regist_button')
        register_button['text'] = '注册'
        register_button['width'] = 5
        register_button['height'] = 2
        register_button.grid(row=4, columnspan=2, pady=10,padx=30)

    def click_regist_button(self,command):
        self.children['regist_button']['command']=command

    def get_username(self):
        return self.children['username_entry'].get()
    def get_password(self):
        return self.children['password_entry'].get()
    def get_passwordnew(self):
        return self.children['password_entrynew'].get()
    def get_nickname(self):
        return  self.children['nick_entry'].get()
if __name__=='__main__':
    registerwindow().mainloop()