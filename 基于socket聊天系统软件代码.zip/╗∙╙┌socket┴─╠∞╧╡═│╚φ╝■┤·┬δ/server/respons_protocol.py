from config import *
class responsprotocol:
    @staticmethod
    def response_login_result(result,nickname,username):

        return DELIMITER.join([RESPONSE_LOGN_RESULT,result,nickname,username])

    @staticmethod
    def response_chat(nickname, messages):
        return DELIMITER.join([RESPONSE_CHAT,  nickname,messages])