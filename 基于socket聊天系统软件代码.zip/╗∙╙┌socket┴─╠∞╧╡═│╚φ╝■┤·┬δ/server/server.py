from sockt_serve import ServerSoket
from socketwapper import SocketWapper
from threading import Thread #开启子线程
from respons_protocol import *
from database import DB
import os
import socket
import struct
class Server(object):
    #服务器核心类
    def __init__(self):#初始化
        self.server_socket=ServerSoket()
        self.request_handle_function={}
        self.request_handle_function[REQUEST_LOGIN]=self.request_login_handle
        self.request_handle_function[REQUEST_CHAT]=self.request_chat_handle
        self.request_handle_function['0003']=self.deal_image
        self.client={}
        self.db=DB()

        # self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # # s.bind(('127.0.0.1', 6666))
        # self.s.bind(('127.0.0.2', 6666))
        # self.s.listen(10)
    #创建服务器套接字
    def startup(self):
        #获取客户端连接，并提供服务
        while True:
            print("正在获取客户端连接.....")
            # sock, addrs = self.s.accept()
            self.soc,self.addr=self.server_socket.accept()
            print("获取客户端连接")
            #使用套接字包装对象
            self.clintsoc=SocketWapper(self.soc)
            #接受客户端消息
            #self.deal_image(sock, addrs)
            t=Thread(target=self.request_handle,args=(self.clintsoc,))#开启多线程
            t.start()

    def request_handle(self,clintsoc):
        while True:
            #接受客户消息
            msg = clintsoc.recv_data()
            #print(msg)
            if not msg:#没有消息则退出
                self.remove_offline_user(clintsoc)
                clintsoc.close()
                break
            if '|' not in msg:
                self.deal_image(self.soc,self.addr,msg)
            else:
            #解析数据：
                parse_data= self.parse_request_text(msg)
                print("获取到解析后内容为%s"%parse_data)
                ##判断请求类型
                handle_function=self.request_handle_function[parse_data["request_id"]]
                if handle_function:#非空才调用函数
                    handle_function(clintsoc,parse_data)


    def remove_offline_user(self,clintsoc):
        print("客户端下线了")
        for username,info in self.client.items():
             if info['sock']==clintsoc:#下线客户的套结字字等于已有的套结字，删除该客户
                del self.client[username]
                print(self.client)
                break


    def parse_request_text(self,msg):
        #解析客户端数据
        #登录信息格式 0001|username|password
        #聊天信息格式 0002|username|msg

        print('解析客户端数据'+msg)
        data_list = msg.split("|")
        request_data={}
        request_data["request_id"]=data_list[0]
        if request_data["request_id"]==REQUEST_LOGIN:
            request_data["username"]=data_list[1]
            request_data["password"]=data_list[2]
        elif request_data["request_id"]==REQUEST_CHAT :
            request_data["username"]=data_list[1]
            request_data["message"]=data_list[2]
        elif request_data["request_id"]=='0003' :
            request_data["filename"] = data_list[1]
            request_data["filemessage"] = data_list[2]
            request_data["size"]=data_list[3]
        return request_data

    def request_login_handle(self,clintsoc,parse_data):

        print("准备登录")

        #获取账号名和密码
        password=parse_data["password"]
        username=parse_data["username"]
        #检查能否登录成功：
        ret,nickname,username=self.check_login(username,password)
        #登录成功则需要保存当前用户：
        if ret=='1':
             self.client[username]={'sock':clintsoc,'nickname':nickname}
            #拼接返回给客户的消息
        respons_text=responsprotocol.response_login_result(ret,nickname,username)
        #给客户发消息：
        clintsoc.send_data(respons_text)


    def request_chat_handle(self,clintsoc,request_data):
        print("准备发信息",request_data )
        #获取消息内容
        username=request_data['username']
        message=request_data['message']
        nickname=self.client[username]['nickname']
        #拼接发送给客户端的消息
        msg=responsprotocol.response_chat(nickname,message)
        #转发消息给在线用户
        for u_name,infor in self.client.items():
            if u_name==username:
                continue
            infor['sock'].send_data(msg)



    def check_login(self,username,password):
        #检查用户是否登录成功，返回检查结果（0失败，1成功），昵称，用户账号
        sql="select * from users1 where user_name='"+username+"'"
        result=self.db.getone(sql)

        #没有结果说明用户不存在
        if not result:
            return '0','','username'
        if password !=result["user_password"]:
            return '0','','username'

        #登录成功
        return '1',result['user_nickname'],username

    def deal_image(self,sock, addr,msg):
               # filesize=int(self.clintsoc.recv_data())
                new_filename = os.path.join('./',
                                            'new_test.txt' )  # 在服务器端新建图片名（可以不用新建的，直接用原来的也行，只要客户端和服务器不是同一个系统或接收到的图片和原图片不在一个文件夹下）

               # recvd_size = 0
                fp = open(new_filename, 'wb')

                #while not recvd_size == filesize:
                   # if filesize - recvd_size > 1024:
                #data = sock.recv(1024)
                        #recvd_size += len(data)
                   # else:
                       # data = sock.recv(1024)
                       # recvd_size = filesize
                print('data is', msg)

                data=msg.encode('utf-8')
                fp.write(data)  # 写入图片数据
                fp.close()


if __name__ == '__main__':
    Server().startup()